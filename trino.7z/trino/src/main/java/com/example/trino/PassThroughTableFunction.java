package com.example.trino;

import io.trino.spi.connector.*;
import io.trino.spi.function.table.*;
import io.trino.spi.type.RowType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static io.trino.spi.function.table.ReturnTypeSpecification.GenericTable.GENERIC_TABLE;
import static java.util.stream.Collectors.toList;

public class PassThroughTableFunction
        extends AbstractConnectorTableFunction {

    public PassThroughTableFunction() {
        super(
                "system",
                "vip",
                List.of(TableArgumentSpecification.builder().name("input_table").rowSemantics().passThroughColumns().build()),
                GENERIC_TABLE);
    }

    @Override
    public TableFunctionAnalysis analyze(ConnectorSession session, ConnectorTransactionHandle transaction, Map<String, Argument> arguments, ConnectorAccessControl accessControl) {
        if (arguments == null || !arguments.containsKey("input_table")) {
            throw new IllegalArgumentException("input_table argument is missing");
        }

        TableArgument inputTable = (TableArgument) arguments.get("input_table");
        if (inputTable == null) {
            throw new IllegalArgumentException("input_table cannot be null");
        }

        RowType rowType = inputTable.getRowType();
        if (rowType == null) {
            throw new IllegalArgumentException("RowType cannot be null");
        }

        List<Descriptor.Field> fields = rowType.getFields().stream()
                .map(field -> new Descriptor.Field(
                        field.getName().orElse("column_"),
                        Optional.of(field.getType())))
                .collect(toList());

        List<RowType.Field> rowFields = rowType.getFields();

        List<Integer> requiredColumnIndexes = new ArrayList<>();
        for (int i = 0; i < rowFields.size(); i++) {
            requiredColumnIndexes.add(i);
        }

        Descriptor returnedType = new Descriptor(fields);

        return TableFunctionAnalysis.builder()
                .returnedType(returnedType)
                .requiredColumns("input_table", requiredColumnIndexes)
                .handle(new PassThroughTableFunctionHandle())
                .build();
    }
}

