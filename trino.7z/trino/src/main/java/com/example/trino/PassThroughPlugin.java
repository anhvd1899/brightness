package com.example.trino;

import io.trino.spi.Plugin;
import io.trino.spi.connector.ConnectorFactory;

import java.util.Set;

public class PassThroughPlugin implements Plugin {
    @Override
    public Set<ConnectorFactory> getConnectorFactories() {
        return Set.of(new PassThroughConnectorFactory());
    }
}
