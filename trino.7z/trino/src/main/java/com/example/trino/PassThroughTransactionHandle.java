package com.example.trino;

import io.trino.spi.connector.ConnectorTransactionHandle;

public enum PassThroughTransactionHandle implements ConnectorTransactionHandle {
    INSTANCE;
}
