package com.example.trino;

import io.trino.spi.function.table.ConnectorTableFunctionHandle;

public class PassThroughTableFunctionHandle implements ConnectorTableFunctionHandle {
    @Override
    public String toString() {
        return "PassThroughTableFunctionHandle{}";
    }
}
