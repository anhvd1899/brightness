package com.example.trino;

import io.trino.spi.connector.ConnectorMetadata;
import io.trino.spi.connector.ConnectorSession;

import java.util.List;
public class PassThroughMetadata implements ConnectorMetadata {
    @Override
    public List<String> listSchemaNames(ConnectorSession session) {
        return List.of("system");
    }
}
