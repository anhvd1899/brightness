package com.example.trino;

import io.trino.spi.connector.Connector;
import io.trino.spi.connector.ConnectorMetadata;
import io.trino.spi.connector.ConnectorSession;
import io.trino.spi.connector.ConnectorTransactionHandle;
import io.trino.spi.function.table.ConnectorTableFunction;
import io.trino.spi.transaction.IsolationLevel;

import java.util.Set;

public class PassThroughConnector implements Connector {
    private static final Set<ConnectorTableFunction> FUNCTIONS = Set.of(new PassThroughTableFunction());
    public ConnectorTransactionHandle beginTransaction(IsolationLevel isolationLevel, boolean readOnly, boolean autoCommit) {
        return PassThroughTransactionHandle.INSTANCE;
    }

    @Override
    public ConnectorMetadata getMetadata(ConnectorSession session, ConnectorTransactionHandle transactionHandle) {
        return new PassThroughMetadata();
    }

//    @Override
//    public Set<ConnectorTableFunction> getTableFunctions() {
//        return Set.of(new PassThroughTableFunction());
//    }

    @Override
    public Set<ConnectorTableFunction> getTableFunctions() {
        return FUNCTIONS;
    }
}

