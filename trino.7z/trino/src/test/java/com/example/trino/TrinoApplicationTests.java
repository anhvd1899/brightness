package com.example.trino;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrinoApplicationTests {

	@Test
	void contextLoads() {
	}

}
